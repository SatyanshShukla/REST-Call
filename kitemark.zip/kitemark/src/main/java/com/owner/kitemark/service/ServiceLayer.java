package com.owner.kitemark.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import VO.User;

@Service
public class ServiceLayer {
	private RestTemplate restTemplate;
	
	@Autowired
	public ServiceLayer(RestTemplate restTemplate) {
		this.restTemplate=restTemplate;
	}
	
	public User consumeAPI() {
		return restTemplate.getForObject("https://jsonplaceholder.typicode.com/todos/1", User.class);
	}

	public void putRequestAPI(int id) {
		User user = new User();
		user.setId(id);user.setUserId(23);user.setTitle("abcd");user.setStatus("efghijkl");
		restTemplate.put("https://jsonplaceholder.typicode.com/todos/1", user);
	}

}
