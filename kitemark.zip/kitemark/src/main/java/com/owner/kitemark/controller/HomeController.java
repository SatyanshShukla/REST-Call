package com.owner.kitemark.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.owner.kitemark.service.ServiceLayer;

import VO.User;

@RestController
public class HomeController {
	
	private final ServiceLayer serviceLayer;
	
	@Autowired
	public HomeController(ServiceLayer serviceLayer) {
		this.serviceLayer = serviceLayer;
	}
	@GetMapping("/get")
	public ResponseEntity<User> getData() {
		return new ResponseEntity<>(serviceLayer.consumeAPI(), HttpStatus.OK);
	}
	@PutMapping("/put/{id}")
	public ResponseEntity<Object> putData(@RequestBody User user, @PathVariable int id) {
		serviceLayer.putRequestAPI(id);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}

}
